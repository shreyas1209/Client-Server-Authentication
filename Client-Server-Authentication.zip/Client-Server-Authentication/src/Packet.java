public interface Packet {
    
    String displayMessage();
    boolean actionComplete();
}
